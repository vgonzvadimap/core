import json
from eeweather import rank_stations
from requests import get, codes
from lambda_utils import format_response, format_error_response
import boto3


def get_kg_climate_zone(lat, lon):
    url = f'http://climateapi.scottpinkelman.com/api/v1/location/{float(lat)}/{float(lon)}'
    try:
        response = get(url)
        if response.status_code != codes.ok:
            return False, dict(error=f"Could not get kg zone from climateapi, status: {response.status_code}, reason: {response.reason}")
        res = response.json()
        kg_zone = res['return_values'][0]['koppen_geiger_zone']
        zone_description = res['return_values'][0]['zone_description']
        return dict(kg_zone=kg_zone, kg_zone_description=zone_description)
    except Exception as e:
        return False, dict(error=f"Could not get kg zone from climateapi, {str(e)}")


def get_iecc_climate_zone(lat, lon, kg_zone):
    def get_iecc_climate_zone_from_kg(kg):
        koppenGeiger_to_IECC_dict = {
            'Cfa': '4A', 'Dfc': '6B', 'Cfc': '7A', 'ET': '7A', 'Dsc': '6B', 'Cfb': '4A', 'Dfb': '6A', 'Dwc': '7A', 'BSk': '5B', 'Csb': '5B',
            'Csa': '3B', 'BSh': '3B', 'BWh': '3B', 'BWk': '3B', 'Dsb': '5B', 'Dfa': '5A', 'Am': '1A', 'Aw': '2A', 'Af': '1A', 'As': '1A', 'Dwb': '6A', 'Dwa': '6A'}
        if kg not in koppenGeiger_to_IECC_dict:
            raise ValueError(
                f'Cannot find any IECC or KG correspondance for coordinates {lat};{lon}')
        else:
            doe_climate_zone = koppenGeiger_to_IECC_dict[kg]
            return doe_climate_zone

    stations_results = rank_stations(
        lat, lon, match_iecc_climate_zone=True, match_iecc_moisture_regime=True)
    print(f'stations results: {stations_results}')

    nearest_result = stations_results[:1]
    print(f'nearest result: {nearest_result}')
    climate_zone = nearest_result.iecc_climate_zone[0]
    print(f'climate zone: {climate_zone}')
    moisture_regime = nearest_result.iecc_moisture_regime[0]
    print(f'moisture regimes: {moisture_regime}')

    if climate_zone is None or moisture_regime is None:
        try:
            doe_climate_zone = get_iecc_climate_zone_from_kg(kg_zone)
        except ValueError as e:
            return dict(error=str(e))
    else:
        doe_climate_zone = climate_zone + '' + moisture_regime

    return dict(iecc_zone=doe_climate_zone)


def handler(event, context):
    # lat: 37.33577030970146, lon: -121.89056396484375 -> for tests
    lat = event.get('arguments').get('lat')
    lon = event.get('arguments').get('lon')
    # kg_zone = event.get('arguments').get('kg_zone')

    kg_climate_zone = get_kg_climate_zone(lat, lon)
    print(f'kg climate zone: {kg_climate_zone}')

    kg_zone = kg_climate_zone.get("kg_zone")

    iecc_climate_zone = get_iecc_climate_zone(lat, lon, kg_zone)

    format_response(iecc_climate_zone)
